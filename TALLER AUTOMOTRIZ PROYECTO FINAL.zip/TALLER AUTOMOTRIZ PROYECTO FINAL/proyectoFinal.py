#librerías
import os
porcentajeIva = 0.19

#FUNCIONES CARGAR ARCHIVOS
def cargar_archivo_servicios(ruta):
    catalogoServicios = {}

    with open(ruta, "r") as archivo:
        archivo.readline()

        for linea in archivo:
            linea = linea.strip()
            if not linea:
                continue
            
            partes = linea.split(",")

            codigoServicio = partes[0]
            descripcion = partes[1]
            costoGasolina = int(partes[2])
            costoDiesel = int(partes[3])
            
            catalogoServicios[codigoServicio] = {
                "descripcion": descripcion,
                "gasolina": costoGasolina,
                "diesel": costoDiesel
            }
    return catalogoServicios

def cargar_archivo_repuestos(ruta):
    inventarioRepuestos = {}

    with open(ruta, "r") as archivo:
        archivo.readline()

        for linea in archivo:
            linea = linea.strip()
            if not linea:
                continue
            
            partes = linea.split(",")

            codigoServicio = partes[0]
            descripcion = partes[1]
            precioUnitario = int(partes[2])
            stock = int(partes[3])
            
            inventarioRepuestos[codigoServicio] = {
                "descripcion": descripcion,
                "precio_unitario": precioUnitario,
                "stock": stock
            }
    return inventarioRepuestos

#FUNCIONES CREADAS PARA EL APARTADO 1

#Función creación de archivo orden cliente
def crear_orden (ruta: str):
    with open(ruta, "w") as archivo:
        pass

#Función Existencia de archivo en carpeta
def validar_existencia_orden (ruta : str):
    return os.path.exists(ruta)

#Función para escribir datos dentro de un archivo
def registrar_en_archivo (ruta : str, informacion : str):
    with open(ruta, "a") as archivo:
        archivo.write(informacion + "\n")

#VARIABLES CREADAS PARA EL APARTADO 2 
"""
rutaDirectorio = ""
"""

# FUNCIONES CREADAS PARA EL APARTADO 2 


try:
    #CARGAR ARCHIVOS
    rutaServicios = "servicios.txt"
    catalogoServicios = cargar_archivo_servicios(rutaServicios)

    rutaRepuestos = "repuestos.csv"
    inventarioRepuestos = cargar_archivo_repuestos(rutaRepuestos)

    rutaDirectorio = "ordenes_abiertas/" 
    dictCombustibleCarro = {} 

    opcion = ""

    while True:
            # IMPRIMIR MENÚ
            print(f"""
        {"="*40}
            FACTURACIÓN TALLER AUTOMOTRIZ
        {"="*40}
        MENÚ
        1. Ingresar Vehículo (Abrir Orden).
        2. Reportar Servicio en Orden.
        3. Cerrar orden (facturacion).
        4. Módulo de reportes (Análisis de datos).
        5. Salir
        """)
            # FIN MENÚ

            opcion = input("Seleccione una opción: ").strip()

            
            #APARTADO 1 : INGRESAR VEHÍCULO
            

            if opcion == "1":
                #PEDIR DATOS
                print("="*40)
                print(" INGRESAR VEHÍCULO")
                print("="*40)

                placa = input("Ingrese la placa del vehículo: ").strip().upper()
                marca = input("Ingrese la marca del vehículo: ").strip()
                tipo = input("Ingrese el tipo de vehículo: ").strip()
                combustible = input("Ingrese tipo de combustible (diesel o gasolina): ").strip()
                idDueno = input("Ingrese el ID del dueño: ").strip()

                #CREAR RUTA DE ORDEN ARCHIVO
                rutaOrden = f"ordenes_abiertas/{placa}.txt"

                #VALIDAR EXISTENCIA DE LA ORDEN
                ordenRepetida = validar_existencia_orden(ruta = rutaOrden)
                if ordenRepetida:
                    print("\nERROR\nYa existe una orden con la misma placa...")
                    continue
                else:
                    #CREAR ORDEN
                    crear_orden(ruta = rutaOrden)

                    #INFORMACIÓN A AÑADIR EN LA ORDEN
                    datosTitular = (f"""
Placa: {placa}
Marca: {marca}
Tipo: {tipo}
Combustible: {combustible}
id_duenio: {idDueno}
""").strip()
                    #DICCIONARIO CON LOS TIPOS DE COMBUSTIBLE DE CADA PLACA

                    dictCombustibleCarro [placa] = combustible.lower().strip()

                    #REGISTRAR LOS DATOS DE EL DUEÑO DE LA ORDEN 
                    registrar_en_archivo(rutaOrden, datosTitular)
                    print("ORDEN CREADA CON ÉXITO.")


            
            
            #APARTADO 2 : REPORTAR SERVICIO EN ORDEN
            
            elif opcion == "2":
                listaOrdenes = []
                ordenes = ""
                placaBuscar = ""
                ruta = ""
                tipoCombustible = ""
                clave = ""
                datosServicio = {}
                servicioBuscar = ""
                descripcionServicio = ""
                costoCombustible = 0
                listaRepuestosUsados = []
                deseaRepuesto = ""
                codigoRepuestoBuscar = ""
                cantidadRepuestoBuscar = 0
                stockDisponible = 0
                precioUnitarioRepuesto = 0
                precioRepuestoTotal = 0
                registroRepuesto = ""
                strRepuestos = ""
                lineaServicio = ""

                print("\nPLACAS REGISTRADAS EN ORDENES ABIERTAS:")
                listaOrdenes = os.listdir(rutaDirectorio)

                for ordenes in listaOrdenes:
                    if ordenes.endswith(".txt"):
                        print(f"- {ordenes.replace('.txt', '')}")

                placaBuscar = input("\nIngrese la placa a reportar en servicio: ").upper().strip()
                ruta = f"ordenes_abiertas/{placaBuscar}.txt"
                
                if not validar_existencia_orden(ruta):
                    print("[ERROR]: Esta placa no existe en ordenes abiertas...")
                    continue

                tipoCombustible = dictCombustibleCarro[placaBuscar]

                # SERVICIO A SELECCIONAR
                print("\nLista de servicios disponibles:")
                for clave, datosServicio in catalogoServicios.items():
                    print(f"Código: {clave} | {datosServicio['descripcion']}")

                servicioBuscar = input("\nIngrese un código de servicio: ").upper().strip()
                if servicioBuscar not in catalogoServicios:
                    print("[ERROR]: Código de servicio inválido.")
                    continue

                # COSTO SEGÚN TIPO DE COMBUSTIBLE
                descripcionServicio = catalogoServicios[servicioBuscar]["descripcion"]
                costoCombustible = catalogoServicios[servicioBuscar][tipoCombustible]
                
                # MANEJO DE REPUESTOS
                listaRepuestosUsados = []

                while True:
                    deseaRepuesto = input("\n¿Desea agregar un repuesto a este servicio? (s/n): ").strip().lower()
                    if deseaRepuesto != "s":
                        break  

                    codigoRepuestoBuscar = input("Ingrese el código del repuesto: ").strip().upper()
                    
                    #Validar existencia ANTES de pedir cantidades
                    if codigoRepuestoBuscar not in inventarioRepuestos:
                        print(f"[ERROR]: El código '{codigoRepuestoBuscar}' no existe en el inventario.")
                        continue

                    cantidadRepuestoBuscar = int(input(f"Ingrese la cantidad solicitada de [{inventarioRepuestos[codigoRepuestoBuscar]['descripcion']}]: "))
                    if cantidadRepuestoBuscar <= 0:
                        print("[ERROR]: La cantidad debe ser mayor a cero.")
                        continue
                    
                    #Validación estricta de Stock físico en RAM
                    stockDisponible = inventarioRepuestos[codigoRepuestoBuscar]["stock"]
                    if cantidadRepuestoBuscar > stockDisponible:
                        print(f"[ERROR]: Stock insuficiente. Solo quedan {stockDisponible} unidades.")
                        continue

                    inventarioRepuestos[codigoRepuestoBuscar]["stock"] -= cantidadRepuestoBuscar

                    # Cálculos financieros individuales
                    precioUnitarioRepuesto = inventarioRepuestos[codigoRepuestoBuscar]["precio_unitario"]
                    precioRepuestoTotal = cantidadRepuestoBuscar * precioUnitarioRepuesto

                    # Empaquetar datos del repuesto (codigo:cantidad:total)
                    registroRepuesto = f"{codigoRepuestoBuscar}:{cantidadRepuestoBuscar}:{precioRepuestoTotal}"
                    listaRepuestosUsados.append(registroRepuesto)
                    print(f"[OK]: Repuesto agregado con éxito.")

                
                # PERSISTENCIA: ESCRITURA EN EL ARCHIVO DE LA ORDEN
                
                # Unir los repuestos con punto y coma si existen
                strRepuestos = ";".join(listaRepuestosUsados) if listaRepuestosUsados else "Sin_Repuestos"
                
                # Armar la línea estructurada según requerimiento técnico:
                # codigo_servicio,descripcion_servicio,costo_mano_obra,[lista_repuestos]
                lineaServicio = f"{servicioBuscar},{descripcionServicio},{costoCombustible},[{strRepuestos}]"
                
                # Escribir de forma persistente (append)
                registrar_en_archivo(ruta, lineaServicio)
                print(f"\n[ÉXITO]: Servicio {servicioBuscar} registrado correctamente en la orden {placaBuscar}.")
                

            
            #   APARTADO 3: CERRAR ORDEN
            
            elif opcion == "3":
                listaArchivosOrdenes = []
                nombreArchivoOrden = ""
                placaParaCerrar = ""
                rutaArchivoOrigen = ""
                fechaEmisionFactura = ""
                sumaSubtotalManoObra = 0
                sumaSubtotalRepuestos = 0
                textoAcumuladoDetallesServicios = ""
                lineasTotalesArchivo = []
                lineasExclusivasServicios = []
                textoDatosVehiculo = ""
                lineaIndividual = ""
                lineaServicio = ""
                partesServicioSeparadas = []
                codigoServicioExtraido = ""
                descripcionServicioExtraida = ""
                costoManoObraExtraido = 0
                textoRepuestosSinProcesar = ""
                textoRepuestosLimpio = ""
                listaRepuestosIndividuales = []
                datosRepuestoUnido = ""
                partesRepuestoSeparadas = []
                codigoRepuestoExtraido = ""
                cantidadRepuestoExtraida = 0
                costoTotalRepuestoExtraido = 0
                nombreRepuestoEncontrado = ""
                subtotalNetoGeneral = 0
                valorImpuestoIva = 0
                granTotalFactura = 0
                rutaArchivoFactura = ""
                rutaArchivoDestino = ""
                lineaGuardar = ""
                codigoRepuestoIterado = ""
                datosRepuestoIterado = {}
                lineaCsvFormateada = ""

                print("\n" + "="*40)
                print(" CERRAR ORDEN (FACTURACIÓN)")
                print("="*40)
                
                print("PLACAS DISPONIBLES PARA FACTURAR:")
                listaArchivosOrdenes = os.listdir(rutaDirectorio)
                
                for nombreArchivoOrden in listaArchivosOrdenes:
                    if nombreArchivoOrden.endswith(".txt"):
                        print(f"- {nombreArchivoOrden.replace('.txt', '')}")
                
                placaParaCerrar = input("\nIngrese la placa de la orden a cerrar: ").upper().strip()
                rutaArchivoOrigen = f"ordenes_abiertas/{placaParaCerrar}.txt"
                
                if not validar_existencia_orden(rutaArchivoOrigen):
                    print("[ERROR]: El archivo de la orden no existe.")
                    continue

                fechaEmisionFactura = input("Ingrese la fecha de hoy (AAAA-MM-DD): ").strip()

                # Acumuladores financieros y de texto descriptivo
                sumaSubtotalManoObra = 0
                sumaSubtotalRepuestos = 0
                textoAcumuladoDetallesServicios = ""

                # Leer el archivo de la orden abierta
                with open(rutaArchivoOrigen, "r") as archivoOrdenAbierta:
                    lineasTotalesArchivo = archivoOrdenAbierta.readlines()

                if len(lineasTotalesArchivo) == 0:
                    print("[ERROR]: El archivo de la orden está vacío.")
                    continue

                for lineaIndividual in lineasTotalesArchivo:
                    lineaIndividual = lineaIndividual.strip()
                    if not lineaIndividual:
                        continue
                    # Si la línea contiene una coma, es un servicio técnico reportado
                    if "," in lineaIndividual:
                        lineasExclusivasServicios.append(lineaIndividual)
                    else:
                        textoDatosVehiculo = textoDatosVehiculo + lineaIndividual + "\n"

                # Procesar cada servicio técnico encontrado
                for lineaServicio in lineasExclusivasServicios:
                    partesServicioSeparadas = lineaServicio.split(",")
                    
                    codigoServicioExtraido = partesServicioSeparadas[0]
                    descripcionServicioExtraida = partesServicioSeparadas[1]
                    costoManoObraExtraido = int(partesServicioSeparadas[2])
                    textoRepuestosSinProcesar = partesServicioSeparadas[3] # Ej: "[R01:2:50000]"
                    
                    sumaSubtotalManoObra = sumaSubtotalManoObra + costoManoObraExtraido
                    textoAcumuladoDetallesServicios = textoAcumuladoDetallesServicios + f"Servicio: {codigoServicioExtraido} - {descripcionServicioExtraida} | Mano de Obra: ${costoManoObraExtraido}\n"
                    
                    # Limpiar los corchetes del texto de repuestos
                    textoRepuestosLimpio = textoRepuestosSinProcesar.replace("[", "").replace("]", "")
                    
                    if textoRepuestosLimpio != "Sin_Repuestos" and textoRepuestosLimpio != "":
                        listaRepuestosIndividuales = textoRepuestosLimpio.split(";")
                        for datosRepuestoUnido in listaRepuestosIndividuales:
                            partesRepuestoSeparadas = datosRepuestoUnido.split(":")
                            
                            codigoRepuestoExtraido = partesRepuestoSeparadas[0]
                            cantidadRepuestoExtraida = int(partesRepuestoSeparadas[1])
                            costoTotalRepuestoExtraido = int(partesRepuestoSeparadas[2])
                            
                            sumaSubtotalRepuestos = sumaSubtotalRepuestos + costoTotalRepuestoExtraido
                            
                            # Buscar el nombre del repuesto en el diccionario de la RAM
                            nombreRepuestoEncontrado = inventarioRepuestos[codigoRepuestoExtraido]["descripcion"]
                            textoAcumuladoDetallesServicios = textoAcumuladoDetallesServicios + f"   -> Repuesto: {codigoRepuestoExtraido} - {nombreRepuestoEncontrado} x{cantidadRepuestoExtraida} | Total: ${costoTotalRepuestoExtraido}\n"

                # Cálculos de impuestos y totales generales
                subtotalNetoGeneral = sumaSubtotalManoObra + sumaSubtotalRepuestos
                valorImpuestoIva = int(subtotalNetoGeneral * porcentajeIva)
                granTotalFactura = subtotalNetoGeneral + valorImpuestoIva

                # GENERAR ARCHIVO DE FACTURA FÍSICA
                rutaArchivoFactura = f"factura_{placaParaCerrar}_{fechaEmisionFactura}.txt"
                with open(rutaArchivoFactura, "w") as archivoFacturaFinal:
                    archivoFacturaFinal.write("="*50 + "\n")
                    archivoFacturaFinal.write("           FACTURA DE VENTA - TALLER\n")
                    archivoFacturaFinal.write(f"Fecha: {fechaEmisionFactura}\n")
                    archivoFacturaFinal.write("="*50 + "\n")
                    archivoFacturaFinal.write("DATOS DEL VEHICULO:\n")
                    archivoFacturaFinal.write(textoDatosVehiculo)
                    archivoFacturaFinal.write("-"*50 + "\n")
                    archivoFacturaFinal.write("DETALLE DEL TRABAJO:\n")
                    archivoFacturaFinal.write(textoAcumuladoDetallesServicios)
                    archivoFacturaFinal.write("-"*50 + "\n")
                    archivoFacturaFinal.write(f"Subtotal Mano de Obra: ${sumaSubtotalManoObra}\n")
                    archivoFacturaFinal.write(f"Subtotal Repuestos:    ${sumaSubtotalRepuestos}\n")
                    archivoFacturaFinal.write(f"Subtotal General:      ${subtotalNetoGeneral}\n")
                    archivoFacturaFinal.write(f"IVA (19%):             ${valorImpuestoIva}\n")
                    archivoFacturaFinal.write(f"GRAN TOTAL A PAGAR:    ${granTotalFactura}\n")
                    archivoFacturaFinal.write("="*50 + "\n")

                print(f"\n[OK]: Factura '{rutaArchivoFactura}' generada exitosamente.")

                # MOVER ARCHIVO A ORDENES CERRADAS
                if not os.path.exists("ordenes_cerradas"):
                    os.makedirs("ordenes_cerradas")
                
                rutaArchivoDestino = f"ordenes_cerradas/{placaParaCerrar}.txt"
                
                # Escribir copia en el directorio histórico
                with open(rutaArchivoDestino, "w") as archivoDestinoHistorico:
                    for lineaGuardar in lineasTotalesArchivo:
                        archivoDestinoHistorico.write(lineaGuardar)
                
                # Eliminar del directorio activo
                os.remove(rutaArchivoOrigen)
                
                # Sacar la placa del diccionario en RAM
                if placaParaCerrar in dictCombustibleCarro:
                    dictCombustibleCarro.pop(placaParaCerrar)
                
                print("[OK]: La orden fue trasladada a 'ordenes_cerradas'.")

                # SOBREESCRIBIR EL ARCHIVO REPUESTOS.CSV CON EL STOCK ACTUALIZADO
                with open(rutaRepuestos, "w") as archivoInventarioCsv:
                    archivoInventarioCsv.write("codigo_servicio,descripcion,precio_unitario,stock\n")
                    for codigoRepuestoIterado, datosRepuestoIterado in inventarioRepuestos.items():
                        lineaCsvFormateada = f"{codigoRepuestoIterado},{datosRepuestoIterado['descripcion']},{datosRepuestoIterado['precio_unitario']},{datosRepuestoIterado['stock']}\n"
                        archivoInventarioCsv.write(lineaCsvFormateada)
                        
                print("[OK]: Base de datos de repuestos.csv guardada en disco.")

            
            #   APARTADO 4: MÓDULO DE REPORTES
            
            elif opcion == "4":
                opcionSubReporte = ""
                controladorExisteStockCritico = False
                codigoRepuesto = ""
                informacionRepuesto = {}
                archivosHistoricosCerrados = []
                cantidadOrdenesCerradasProcesadas = 0
                acumuladoTotalManoObraHistorica = 0
                acumuladoTotalRepuestosHistoricos = 0
                archivoTextoCerrado = ""
                rutaArchivoHistorial = ""
                lineasArchivoHistorial = []
                lineaHistorial = ""
                partesLineaHistorica = []
                costoManoObraHistorico = 0
                bloqueRepuestosHistorico = ""
                listaRepuestosHistoricos = []
                datosRepuestoHistorico = ""
                partesRepuestoHistorico = []
                subtotalFinancieroHistorico = 0
                ivaFinancieroHistorico = 0
                granTotalRecaudadoHistorico = 0

                print("\n" + "="*40)
                print(" MÓDULO DE REPORTES Y ANÁLISIS")
                print("="*40)
                print("1. Reporte de Stock Crítico (Menos de 5 unidades)")
                print("2. Resumen financiero de Órdenes Cerradas")
                print("3. Volver al menú")
                
                opcionSubReporte = input("Seleccione tipo de reporte: ").strip()
                
                if opcionSubReporte == "1":
                    print("\n--- REPUESTOS CON STOCK CRÍTICO (< 5) ---")
                    for codigoRepuesto, informacionRepuesto in inventarioRepuestos.items():
                        if informacionRepuesto["stock"] < 5:
                            print(f"Código: {codigoRepuesto} | {informacionRepuesto['descripcion']} | Quedan: {informacionRepuesto['stock']} unidades")
                            controladorExisteStockCritico = True
                    if not controladorExisteStockCritico:
                        print("No hay repuestos en estado crítico. Todo el stock es óptimo.")
                        
                elif opcionSubReporte == "2":
                    print("\n--- PROCESANDO HISTÓRICO DE ÓRDENES CERRADAS ---")
                    if not os.path.exists("ordenes_cerradas"):
                        print("No existe la carpeta de historial o no hay órdenes cerradas todavía.")
                        continue
                        
                    archivosHistoricosCerrados = os.listdir("ordenes_cerradas")

                    for archivoTextoCerrado in archivosHistoricosCerrados:
                        if archivoTextoCerrado.endswith(".txt"):
                            cantidadOrdenesCerradasProcesadas = cantidadOrdenesCerradasProcesadas + 1
                            rutaArchivoHistorial = f"ordenes_cerradas/{archivoTextoCerrado}"
                            
                            with open(rutaArchivoHistorial, "r") as archivoLectorHistorial:
                                lineasArchivoHistorial = archivoLectorHistorial.readlines()
                                
                            for lineaHistorial in lineasArchivoHistorial:
                                lineaHistorial = lineaHistorial.strip()
                                if "," in lineaHistorial:
                                    partesLineaHistorica = lineaHistorial.split(",")
                                    costoManoObraHistorico = int(partesLineaHistorica[2])
                                    bloqueRepuestosHistorico = partesLineaHistorica[3]
                                    
                                    acumuladoTotalManoObraHistorica = acumuladoTotalManoObraHistorica + costoManoObraHistorico
                                    
                                    bloqueRepuestosHistorico = bloqueRepuestosHistorico.replace("[", "").replace("]", "")
                                    if bloqueRepuestosHistorico != "Sin_Repuestos" and bloqueRepuestosHistorico != "":
                                        listaRepuestosHistoricos = bloqueRepuestosHistorico.split(";")
                                        for datosRepuestoHistorico in listaRepuestosHistoricos:
                                            partesRepuestoHistorico = datosRepuestoHistorico.split(":")
                                            if len(partesRepuestoHistorico) == 3:
                                                acumuladoTotalRepuestosHistoricos = acumuladoTotalRepuestosHistoricos + int(partesRepuestoHistorico[2])
                    
                    subtotalFinancieroHistorico = acumuladoTotalManoObraHistorica + acumuladoTotalRepuestosHistoricos
                    ivaFinancieroHistorico = int(subtotalFinancieroHistorico * porcentajeIva)
                    granTotalRecaudadoHistorico = subtotalFinancieroHistorico + ivaFinancieroHistorico
                    
                    print(f"Cantidad de órdenes cerradas evaluadas: {cantidadOrdenesCerradasProcesadas}")
                    print(f"Total recaudado por Mano de Obra:       ${acumuladoTotalManoObraHistorica}")
                    print(f"Total recaudado por Repuestos:          ${acumuladoTotalRepuestosHistoricos}")
                    print(f"Total IVA recaudado histórico:          ${ivaFinancieroHistorico}")
                    print(f"Gran Total Facturado Histórico:         ${granTotalRecaudadoHistorico}")
                    
                elif opcionSubReporte == "3":
                    continue


            elif opcion == "5":
                print("Saliendo del sistema...")
                break
            else:
                print("OPCIÓN INVÁLIDA. Intente de nuevo.")
                pass
except Exception as e:
    print(e)
